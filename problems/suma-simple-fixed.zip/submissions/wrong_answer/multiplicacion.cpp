#include <iostream>
using namespace std;

int main() {
    int a, b;
    cin >> a >> b;
    cout << a * b << endl;  // Error: multiplica en vez de sumar
    return 0;
}